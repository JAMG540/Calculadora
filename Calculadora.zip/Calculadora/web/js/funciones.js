function operar(numero)
{
    var operacion=document.getElementById("operacion");
    var asigna=numero;
    
    operacion.value=asigna;
}
   


